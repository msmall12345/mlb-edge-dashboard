# MLB Edge — Upload Screenshot → Picks (No-Code Dashboard)

This Streamlit app lets you upload a sportsbook screenshot, OCR the odds, pull live MLB data, and compute edges & Kelly stakes with the included model.

## Quick start
1. Install Python 3.10+
2. Create and activate a virtualenv (recommended).
3. Install deps:
   ```bash
   pip install -r requirements.txt
   ```
4. Run the dashboard:
   ```bash
   streamlit run app.py
   ```
5. In the browser:
   - Upload one or more screenshots of a **moneyline** slate.
   - Review/edit the parsed table.
   - Click **Run Analysis** to get fair probabilities, edges, and suggested stakes.
   - Download results as CSV.

### Notes
- OCR uses **rapidocr-onnxruntime** by default (no system install). If it fails, it will try **pytesseract** (requires system Tesseract).
- Odds are read from your screenshot. Team/player data is fetched live (internet required).
- The included model is a baseline; weights can be tuned later.
