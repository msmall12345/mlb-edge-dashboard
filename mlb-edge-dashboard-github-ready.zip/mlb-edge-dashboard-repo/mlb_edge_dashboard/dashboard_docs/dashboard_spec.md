# Dashboard Spec (Edge Ops v1)

## Pages
1) **Today’s Edges**
   - Table: game, market, book, price, model fair, edge %, EV, stake (Kelly), confidence tier, last updated.
   - Filters: min EV, market type, books, time window.
   - Badges: Lineup confirmed, Weather risk, Pen fatigue.

2) **CLV & Performance**
   - Charts: Closing line vs our price (basis in cents), bankroll curve, ROI by market, EV calibration.
   - Table: Top 10 best/worst edges realized, variance diagnostics.

3) **Game Drilldown**
   - Feature deltas: SP Δ, Bullpen Δ, Offense Δ (vs handedness), Defense Δ, Env factor.
   - What-if toggles: swap SP, adjust weather, lineup changes.

4) **Settings**
   - Risk dials: Kelly fraction, EV threshold, game/day caps.
   - Data freshness indicators.

## Data Sources
- `model_outputs`, `odds`, `bets`, `results`
- Refresh: every 15–30 minutes on game day.

## Confidence Tiering
- **A**: EV ≥ 4%, lineup confirmed, market width ≤ 8c, no injury flags.
- **B**: EV 2–4%, lineup pending or minor flags.
- **C**: EV 1–2%, experimental or low-liquidity.

## Alerts
- Slack/email payload: game_id, market, book, price, fair, EV, stake, flags.
