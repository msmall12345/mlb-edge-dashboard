from __future__ import annotations
import argparse, datetime as dt, json, os
from .pipeline import run_day

def main():
    parser = argparse.ArgumentParser(description="MLB Edge Detector CLI")
    parser.add_argument("command", choices=["recommend"], help="Action to perform")
    parser.add_argument("--date", dest="date", default=None, help="YYYY-MM-DD; default today")
    parser.add_argument("--bankroll", dest="bankroll", type=float, default=100000.0, help="Bankroll size")
    parser.add_argument("--mock", dest="mock", action="store_true", help="Use mock data")
    args = parser.parse_args()

    date = args.date or dt.datetime.now().strftime("%Y-%m-%d")
    if args.command == "recommend":
        result = run_day(date, bankroll=args.bankroll, mock=args.mock)
        print(json.dumps(result, indent=2))
        print(f"\nSaved: {result['file']}")

if __name__ == "__main__":
    main()
