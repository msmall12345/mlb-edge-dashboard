from __future__ import annotations
from typing import Tuple
from .utils import american_to_decimal

def kelly_stake(bankroll: float, price: int, p: float, kelly_fraction: float=0.5, max_pct: float=0.02) -> float:
    b = american_to_decimal(price) - 1.0
    q = 1.0 - p
    edge = b*p - q
    if edge <= 0:
        return 0.0
    f_star = (edge / b) * kelly_fraction
    stake = bankroll * min(f_star, max_pct)
    return max(0.0, stake)

def expected_ev(price: int, p: float, stake: float) -> float:
    b = american_to_decimal(price) - 1.0
    return p * b * stake - (1-p) * stake
