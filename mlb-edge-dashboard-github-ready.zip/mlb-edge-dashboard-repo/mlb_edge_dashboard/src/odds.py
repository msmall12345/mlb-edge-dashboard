from __future__ import annotations
from typing import Dict, Tuple
from .utils import american_to_decimal, decimal_to_american

def devig_proportional(home_price: int, away_price: int) -> Tuple[float,float]:
    """Return vig-removed probabilities (home, away) using proportional method."""
    dh = american_to_decimal(home_price)
    da = american_to_decimal(away_price)
    ph = 1.0/dh
    pa = 1.0/da
    overround = ph + pa
    ph_fair = ph/overround
    pa_fair = pa/overround
    return ph_fair, pa_fair

def best_line(lines: Dict[str,int]) -> Tuple[str,int]:
    """Pick the best (highest EV potential) line; for fav take lowest negative, for dog take highest positive."""
    # Simple heuristic: choose numerically larger American for underdogs, numerically smaller (closer to zero) for favorites.
    best_book, best_price = None, None
    for book, price in lines.items():
        if best_price is None:
            best_book, best_price = book, price
            continue
        if price > 0:  # dog
            if price > best_price:
                best_book, best_price = book, price
        else:  # favorite
            if price > best_price:  # e.g., -120 is better than -130
                best_book, best_price = book, price
    return best_book, best_price
