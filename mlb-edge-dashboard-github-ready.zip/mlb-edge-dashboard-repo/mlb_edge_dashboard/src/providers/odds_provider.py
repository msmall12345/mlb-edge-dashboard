from __future__ import annotations
import os, requests, datetime as dt
from typing import Dict, Any

class OddsProvider:
    "
    Generic odds provider. Replace with your vendor endpoint.
    Expected return shape for get_ml_prices(game_key):
      { 'pinnacle': {'home': -120, 'away': +110}, 'circa': {'home': -118, 'away': +108} }
    "
    def __init__(self, base_url: str, api_key: str=None):
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key

    def headers(self):
        if not self.api_key:
            return {}
        return {'Authorization': f'Bearer {self.api_key}'}

    def get_ml_prices(self, home_team: str, away_team: str, date: str) -> Dict[str, Any]:
        # Placeholder pattern; change to your vendor route & params
        # Example: GET {base_url}/mlb/odds?date=YYYY-MM-DD&home=NYY&away=BOS
        url = f"{self.base_url}/mlb/odds"
        params = {'date': date, 'home': home_team, 'away': away_team}
        r = requests.get(url, params=params, headers=self.headers(), timeout=20)
        r.raise_for_status()
        return r.json()
