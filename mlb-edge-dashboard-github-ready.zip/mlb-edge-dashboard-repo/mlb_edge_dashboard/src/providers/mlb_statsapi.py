from __future__ import annotations
import datetime as dt
from typing import List, Dict, Any, Optional

try:
    import statsapi  # pip install MLB-StatsAPI
except Exception as e:
    statsapi = None

class MLBStatsAPIClient:
    def __init__(self):
        if statsapi is None:
            raise RuntimeError("MLB-StatsAPI not installed. Run: pip install MLB-StatsAPI")
    
    def schedule(self, date: dt.date) -> List[Dict[str, Any]]:
        # returns list of dicts with basic game info
        return statsapi.schedule(date.strftime('%m/%d/%Y'))

    def probable_pitchers(self, game_pk: int) -> Dict[str, Any]:
        # Pull boxscore_data or game content for probables
        # Using boxscore_data as a simple route
        data = statsapi.boxscore_data(game_pk)
        home = data.get('teams', {}).get('home', {})
        away = data.get('teams', {}).get('away', {})
        return {
            'home_sp': home.get('pitchers', [None])[0] if home.get('pitchers') else None,
            'away_sp': away.get('pitchers', [None])[0] if away.get('pitchers') else None,
        }
