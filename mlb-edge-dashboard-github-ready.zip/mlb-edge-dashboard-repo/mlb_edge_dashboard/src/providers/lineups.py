from __future__ import annotations
from typing import Dict, Any, Optional

class LineupProvider:
    "
    Stub for a lineups provider (e.g., paid feed). Implement fetch_lineup(game_pk) -> dict
    "
    def __init__(self):
        pass

    def fetch_lineup(self, game_pk: int) -> Dict[str, Any]:
        raise NotImplementedError("Wire this to your lineup data source.")
