from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any

@dataclass
class GameFeatures:
    game_id: str
    sp_delta: float
    pen_delta: float
    lineup_delta: float
    defense_delta: float
    env_factor: float
    travel_delta: float
    prior_delta: float
    home_field: float = 0.0

def build_features_stub(game_row: Dict[str,Any]) -> GameFeatures:
    """Stub: Replace with real feature engineering pulling from your DB/API."""
    gid = game_row["game_id"]
    # Dummy values to allow pipeline scaffolding
    return GameFeatures(
        game_id=gid,
        sp_delta=game_row.get("sp_delta", 0.1),
        pen_delta=game_row.get("pen_delta", 0.05),
        lineup_delta=game_row.get("lineup_delta", 0.08),
        defense_delta=game_row.get("defense_delta", 0.02),
        env_factor=game_row.get("env_factor", 0.01),
        travel_delta=game_row.get("travel_delta", -0.01),
        prior_delta=game_row.get("prior_delta", 0.0),
        home_field=game_row.get("home_field", 0.03),
    )
