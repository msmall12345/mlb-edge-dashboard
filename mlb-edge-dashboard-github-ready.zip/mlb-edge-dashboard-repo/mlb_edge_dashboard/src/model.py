from __future__ import annotations
from typing import List
from .feature_builders import GameFeatures
from .utils import logistic

class LogisticModelV1:
    """Simple interpretable baseline: p(home_win) = logistic(w · x)."""
    def __init__(self):
        # Initial heuristic weights matching the signal stack
        self.w = {
            "sp_delta": 3.5,
            "pen_delta": 2.0,
            "lineup_delta": 2.5,
            "defense_delta": 0.7,
            "env_factor": 0.6,
            "travel_delta": 0.2,
            "prior_delta": 0.5,
            "home_field": 0.5,
        }

    def predict_proba(self, feats: GameFeatures) -> float:
        z = sum(getattr(feats, k) * self.w[k] for k in self.w)
        return logistic(z)

def fair_moneyline_from_prob(p: float) -> int:
    p = max(min(p, 0.999999), 0.000001)
    if p > 0.5:
        return int(round(-100 * p / (1 - p)))
    else:
        return int(round(100 * (1 - p) / p))
