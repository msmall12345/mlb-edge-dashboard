from __future__ import annotations
import math
from typing import Tuple

def american_to_decimal(price: int) -> float:
    if price > 0:
        return 1 + price/100.0
    else:
        return 1 + 100.0/abs(price)

def decimal_to_american(dec: float) -> int:
    if dec >= 2.0:
        return int(round((dec - 1.0) * 100))
    else:
        return int(round(-100.0 / (dec - 1.0)))

def prob_to_american(p: float) -> int:
    # fair American line from probability
    p = min(max(p, 1e-6), 1-1e-6)
    if p > 0.5:
        return int(round(-100 * p / (1 - p)))
    else:
        return int(round(100 * (1 - p) / p))

def logistic(x: float) -> float:
    return 1.0/(1.0 + math.exp(-x))
